<?php 
include_once "main-parametres.php"; //inclusion des param�tres principaux

//D�finition des repertoires cl�s
$image=$rootPath."Images/"; 				//repertoire images
$css=$rootPath."Css/";						//repertoire css
$js=$rootPath."Js/";						//repertoire javascript
?>