					</div>
				</div>
			</div>
		</div>
		<?php include_once $rootPath."structure/footer/content-footer.php";?>
		<br/>
	</div>
</body>
</html>