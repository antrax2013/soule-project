<div id="Footer" class="ui-widget ui-widget-header">
	<a href="<?php echo $rootPath?>mentions-legales.php">Mentions légales</a>
	<a href="<?php echo $rootPath?>index.php" title="soule.royale.free.fr"><img id="icone" src="<?php echo $image?>soule-royale-min.png" alt="<?php echo $siteName?>" title="<?php echo $siteName?>"  /></a>
	<a href="<?php echo $rootPath?>site-map.php" title="Soule royale: le plan du site">Plan du site</a>
</div>