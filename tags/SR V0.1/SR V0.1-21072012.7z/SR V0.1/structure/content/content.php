<div id="Main-Content">
	<?php include_once $rootPath."structure/content/news-content.php";?>
	<!-- < ?php include_once $rootPath."structure/content/menu-vertical.php";?> -->
	<div id="Content-Page" class="ui-widget ui-corner-all">
		<div id="Content" class="ui-widget ui-corner-all">
			<?php include_once $rootPath."structure/content/menu-navigation.php";?>
			<div id="Page" class="ui-corner-all" style="">