<div id="News-Content">
	<ul id="News-Scroll"><li><a href="#">08/04/2012 - Mise en ligne du site Soule Royale. Il n'est pas encore possible de jouer mais nous y travaillons. Walegen et Antrax</a></li></ul>
</div>