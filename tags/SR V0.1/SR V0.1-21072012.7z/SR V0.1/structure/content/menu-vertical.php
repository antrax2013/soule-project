<div id="Content-Menu" class="ui-widget ui-accordion ui-corner-all">
	<div id="Menu-Vertical" class="">
		<div id="Menu-Vertical-Inner-Content" class="ui-widget ui-corner-all" style="border:none;">
			<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-corner-top" style="margin-left:-1px; margin-right:-1px;" >
				<a href="#" style="padding-left:2em"><span class="ui-icon ui-icon-triangle-1-e">&nbsp;</span>Section 1</a>
			</h3>
			<div class="ui-helper-reset ui-corner-bottom ui-accordion-content-active" style="height: 122px; display: block;">
				<ul>
					<li>List item one</li>
					<li>List item two</li>
					<li>List item three</li>
				</ul>
			</div>
			<h3 class="ui-accordion-header ui-helper-reset ui-state-default" style="border-left:none;border-right:none" >
				<a href="#" style="padding-left:2em"><span class="ui-icon ui-icon-triangle-1-e">&nbsp;</span>Section 2</a>
			</h3>
			<div class="ui-helper-reset ui-corner-bottom ui-accordion-content-active" style="height: 122px; display: block;">
				<ul>
					<li>List item one</li>
					<li>List item two</li>
					<li>List item three</li>
				</ul>
			</div>
		</div>			
	</div>
</div>