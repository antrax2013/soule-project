<div id="Header" class="ui-corner-all">	
	<?php include_once "button-header.php"; ?>
	<div id="Cartouche-Haut" class="ui-widget">
		<a href="<?php echo $rootPath?>index.php" title="<?php echo $siteName?>">
			<img id="logo" src="<?php echo $image?>soule-royale-main.png" title="<?php echo $siteName?>" alt="<?php echo $siteName?>"  />
		</a>
	</div>
	<?php include_once "menu-header.php"; ?>
</div>