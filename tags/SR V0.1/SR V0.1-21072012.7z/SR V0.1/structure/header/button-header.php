<div id="Main-Button">
	<!-- <div>
		<a id="button-login" href="#" title="Soule Royale: accéder à son compter" class="button">Connexion</a>&nbsp;
		<a id="button-creer-equipe" href="#" title="Soule Royale: créer son équipe" class="button" >Créer son équipe</a>
	</div> -->
	<div><g:plusone size="small"></g:plusone></div>
</div>