<?php 
	$rootPath="";
	$currentPath=$rootPath;
	$structurePath=$rootPath."structure/";
	$page="Les nouveautés";
	$title=$page;
	$desc="Page présentant les dernières évolutions du jeu Soule Royale. Jouable entièrement dans un navigateur web, sans téléchargement. Soyez fin stratége pour mener votre équipe hauts sommets.";
	include_once $structurePath."header/header.php";
	include_once $structurePath."content/content.php";	
?>
<h1>Les nouveautés</h1>
<h2>A venir courrant 2012</h2>
<p>Mise en place du moteur de rendu graphique et des interfaces pour communiquer avec le moteur du jeu.</p>
<hr />
<h2>2012 Avril - Ouverture du site <a href="http://soule.royale.free.fr">soule.royale.free.fr</a></h2>
<p>Le site <a href="http://soule.royale.free.fr">soule royale</a> est ouvert. Les premières pages sont mises en ligne. D'autres viendront étoffer le site. L'objectif d'une mise en ligne très en amont dans le cycle de vie du projet, est de permettre aux moteurs de recherches de commencer à référencer le site pour qu'à son ouverture au public, il soit visible de tous.</p>
<h2>2012 Mars - Création du site <a href="http://soule.royale.free.fr">soule.royale.free.fr</a></h2>
<p>Le site est créé par free. Dans un premier temps l'hébergement sera assuré par free. On déménagera selon les besoins sur un autre serveur. Mais dans un premier temps c'est suffisant et gratuit.</p>
<hr />
<h2>2011 Septembre - Finalisation de la version beta du moteur (V0.1b)</h2>
<p>La première version du moteur est déboguée. Elle semble prête à arbitrer nos matchs... Ca sent bon. Il faut maintenant porter cela dans une interface pour la renseigner. Cette version est juste capable de réaliser les initiales et actions sur un match sans prise en compte du rendu graphique.</p>
<h2>2011 Juillet - Lancement du projet</h2>
<p>Depuis de nombreux mois, nous avons arrêté les RR et donc, par la force des choses, la <strong>soule</strong>. Bien que l'envie de se faire un petit match de <strong>soule</strong> soit intacte, comment trouver un arbitre pour se faire un match entre ami en dehors du cadre des RR. Or comme beaucoup d'entre vous le savent, trouver un arbitre n'est pas forcément chose aisée en temps normal. D'où l'idée de créer un moteur de jeu capable d'interpréter les actions et ainsi s'affranchir d'un l'arbitrage manuel.</p>
<?php include_once "structure/footer/footer.php";?>